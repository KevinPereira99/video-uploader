<h1 align="center">
    <img alt="FinalAssignment" title="#chat" src="video-uploader.svg" width="200px" />
</h1>

<h4 align="center">
  🚀 Video Uploader
</h4>

<p align="center">
  <a href="#-technologies">Technologies</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-project">Project</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#memo-license">License</a>
</p>

<br>

## 🚀 Technologies

This project was developed with the following technologies:

- [Node.js](https://nodejs.org/en/)
- [Sequelize](https://sequelize.org/)

## 💻 Project

The video-uploader consists in a api capable of uploading videos.

## :memo: License

This project is unde the MIT license. Open [LICENSE](LICENSE.md) archive to get more info

---

Done with ♥ by edunt3r :wave:
